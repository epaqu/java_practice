
interface Animal
{
	String getType();
	String getSound();
}

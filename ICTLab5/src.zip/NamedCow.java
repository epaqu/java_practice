
public class NamedCow extends Cow
{
	private String name;
	public NamedCow(String nm)
	{
		super();
		name = nm;
	}
	public String getName()
	{
		return name;
	}
}

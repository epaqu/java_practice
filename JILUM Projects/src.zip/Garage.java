import java.util.ArrayList;

public class Garage
{
	private ArrayList<Auto> garage = new ArrayList<Auto>();
	public Garage()
	{
	}
	public Garage(ArrayList<Auto> myGarage)
	{
		garage = myGarage;
	}
	public double averageMiles()
	{
		double avg = 0.0;
		for (int i = 0; i < garage.size(); i++)
			avg += (double) garage.get(i).getMilesDriven();
		avg /= garage.size();
		return avg;
	}
	public String garageStatus()
	{
		if (garage.size() >= 100)
			return "full";
		else if (garage.size() > 25)
			return "normal load";
		else
			return "below minimum";
	}
	public double totalGallons()
	{
		double total = 0.0;
		for (int i = 0; i < garage.size(); i++)
			total += garage.get(i).getGallonsOfGas();
		return total;
	}
}

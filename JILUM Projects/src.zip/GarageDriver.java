import java.util.ArrayList;

public class GarageDriver {
	public static void main (String[] args)
	{

		ArrayList<Auto> aGarage = new ArrayList<Auto>();
		Auto defaultAuto = new Auto("Carmy", 15, 100.0);
		Auto mustang = new Auto("Mustang", 38, 1800.0);
		for (int i = 0; i < 37; i++)
			aGarage.add(defaultAuto);
		for (int i = 37; i < 89; i++)
			aGarage.add(mustang);
		Garage firstGarage = new Garage(aGarage);
		System.out.println(firstGarage.averageMiles());
		System.out.println(firstGarage.garageStatus());
		System.out.println(firstGarage.totalGallons());
		System.out.println(aGarage.get(2).getModel());
	}
}
